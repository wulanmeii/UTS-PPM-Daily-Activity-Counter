import '../models/activity_model.dart';

class ActivityData {
  final List<ActivityModel> activities = [
    ActivityModel(id: '1', name: 'Minum Air Putih', count: 5),
    ActivityModel(id: '2', name: 'Membaca Buku', count: 2),
    ActivityModel(id: '3', name: 'Olahraga', count: 1),
    ActivityModel(id: '4', name: 'Mengerjakan Tugas', count: 3),
  ];
}
