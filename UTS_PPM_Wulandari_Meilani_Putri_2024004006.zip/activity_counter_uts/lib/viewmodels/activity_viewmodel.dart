import 'package:flutter/material.dart';

import '../models/activity_model.dart';
import '../repositories/activity_repository.dart';

class ActivityViewModel extends ChangeNotifier {
  final ActivityRepository _repository = ActivityRepository();

  List<ActivityModel> get activities => _repository.getAllActivities();

  ActivityModel? getActivityById(String id) {
    try {
      return activities.firstWhere((item) => item.id == id);
    } catch (e) {
      return null;
    }
  }

  void addActivity(String name) {
    final newActivity = ActivityModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: name,
      count: 0,
    );
    _repository.addActivity(newActivity);
    notifyListeners();
  }

  void editActivityName(String id, String newName) {
    _repository.updateActivityName(id, newName);
    notifyListeners();
  }

  void deleteActivity(String id) {
    _repository.deleteActivity(id);
    notifyListeners();
  }

  void incrementCounter(String id) {
    final activity = getActivityById(id);
    if (activity != null) {
      _repository.updateCounter(id, activity.count + 1);
      notifyListeners();
    }
  }

  void decrementCounter(String id) {
    final activity = getActivityById(id);
    if (activity != null && activity.count > 0) {
      _repository.updateCounter(id, activity.count - 1);
      notifyListeners();
    }
  }

  void resetCounter(String id) {
    _repository.updateCounter(id, 0);
    notifyListeners();
  }
}
