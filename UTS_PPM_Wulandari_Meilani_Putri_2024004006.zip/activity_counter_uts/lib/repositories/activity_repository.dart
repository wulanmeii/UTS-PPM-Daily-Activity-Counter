import '../data/activity_data.dart';
import '../models/activity_model.dart';

class ActivityRepository {
  final ActivityData _data = ActivityData();

  List<ActivityModel> getAllActivities() {
    return _data.activities;
  }

  void addActivity(ActivityModel activity) {
    _data.activities.add(activity);
  }

  void updateActivityName(String id, String newName) {
    final index = _data.activities.indexWhere((item) => item.id == id);
    if (index != -1) {
      _data.activities[index].name = newName;
    }
  }

  void deleteActivity(String id) {
    _data.activities.removeWhere((item) => item.id == id);
  }

  void updateCounter(String id, int newCount) {
    final index = _data.activities.indexWhere((item) => item.id == id);
    if (index != -1) {
      _data.activities[index].count = newCount;
    }
  }
}
