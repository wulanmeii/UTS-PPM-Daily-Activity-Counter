import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../viewmodels/activity_viewmodel.dart';
import 'activity_form_view.dart';
import 'activity_detail_view.dart';

class HomeView extends StatelessWidget {
  const HomeView({super.key});

  IconData _getIconForActivity(String name) {
    final lower = name.toLowerCase();
    if (lower.contains('air') || lower.contains('minum')) {
      return Icons.water_drop;
    }
    if (lower.contains('baca') || lower.contains('buku')) {
      return Icons.menu_book;
    }
    if (lower.contains('olahraga') || lower.contains('lari')) {
      return Icons.self_improvement;
    }
    if (lower.contains('tugas') || lower.contains('belajar')) {
      return Icons.assignment;
    }
    return Icons.track_changes;
  }

  @override
  Widget build(BuildContext context) {
    final viewModel = context.watch<ActivityViewModel>();
    final activities = viewModel.activities;

    return Scaffold(
      backgroundColor: const Color(0xFFF6F9F6),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Daily Activity Counter',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF5A8F69),
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        "Today's\nProgress",
                        style: TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          height: 1.15,
                          color: Color(0xFF1E2923),
                        ),
                      ),
                    ],
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFFE3EFE5),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      '${activities.length} Aktivitas',
                      style: const TextStyle(
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF2E5A3C),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              Expanded(
                child: activities.isEmpty
                    ? const Center(
                        child: Text(
                          'Belum ada aktivitas. Tekan + untuk menambah.',
                        ),
                      )
                    : GridView.builder(
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2,
                              crossAxisSpacing: 16,
                              mainAxisSpacing: 16,
                              childAspectRatio: 0.9,
                            ),
                        itemCount: activities.length,
                        itemBuilder: (context, index) {
                          final activity = activities[index];
                          final progress =
                              (activity.count % 10) / 10 == 0 &&
                                  activity.count > 0
                              ? 1.0
                              : (activity.count % 10) / 10;

                          return GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => ActivityDetailView(
                                    activityId: activity.id,
                                  ),
                                ),
                              );
                            },
                            child: Container(
                              padding: const EdgeInsets.all(14),
                              decoration: BoxDecoration(
                                color: const Color(0xFFEAF3EC),
                                borderRadius: BorderRadius.circular(24),
                              ),
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Align(
                                    alignment: Alignment.topRight,
                                    child: InkWell(
                                      onTap: () {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (_) => ActivityFormView(
                                              activity: activity,
                                            ),
                                          ),
                                        );
                                      },
                                      child: const Icon(
                                        Icons.edit_outlined,
                                        size: 18,
                                        color: Color(0xFF4A7C59),
                                      ),
                                    ),
                                  ),
                                  Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      SizedBox(
                                        width: 64,
                                        height: 64,
                                        child: CircularProgressIndicator(
                                          value: activity.count == 0
                                              ? 0.05
                                              : progress,
                                          strokeWidth: 6,
                                          backgroundColor: const Color(
                                            0xFFD0E3D4,
                                          ),
                                          valueColor:
                                              const AlwaysStoppedAnimation<
                                                Color
                                              >(Color(0xFF5A9E6F)),
                                        ),
                                      ),
                                      Icon(
                                        _getIconForActivity(activity.name),
                                        size: 26,
                                        color: const Color(0xFF3B6E4C),
                                      ),
                                    ],
                                  ),
                                  Column(
                                    children: [
                                      Text(
                                        activity.name,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.center,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 15,
                                          color: Color(0xFF1E2923),
                                        ),
                                      ),
                                      const SizedBox(height: 2),
                                      Text(
                                        '${activity.count} Kali',
                                        style: const TextStyle(
                                          fontSize: 13,
                                          fontWeight: FontWeight.w500,
                                          color: Color(0xFF5A8F69),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: const Color(0xFF4A7C59),
        foregroundColor: Colors.white,
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const ActivityFormView()),
          );
        },
        icon: const Icon(Icons.add),
        label: const Text('Aktivitas'),
      ),
    );
  }
}
