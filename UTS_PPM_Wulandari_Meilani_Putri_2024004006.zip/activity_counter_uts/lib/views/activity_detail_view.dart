import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../viewmodels/activity_viewmodel.dart';

class ActivityDetailView extends StatelessWidget {
  final String activityId;

  const ActivityDetailView({super.key, required this.activityId});

  void _showResetDialog(BuildContext context, ActivityViewModel viewModel) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Reset Counter'),
        content: const Text('Kembalikan hitungan aktivitas ini menjadi 0?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () {
              viewModel.resetCounter(activityId);
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Counter berhasil di-reset ke 0')),
              );
            },
            child: const Text('Reset'),
          ),
        ],
      ),
    );
  }

  void _showDeleteDialog(BuildContext context, ActivityViewModel viewModel) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hapus Aktivitas'),
        content: const Text('Yakin ingin menghapus aktivitas ini dari daftar?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () {
              Navigator.pop(ctx);
              Navigator.pop(context);
              viewModel.deleteActivity(activityId);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Aktivitas berhasil dihapus')),
              );
            },
            child: const Text('Hapus', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final viewModel = context.watch<ActivityViewModel>();
    final activity = viewModel.getActivityById(activityId);

    if (activity == null) {
      return const Scaffold(body: Center(child: Text('Data tidak ditemukan')));
    }

    return Scaffold(
      backgroundColor: const Color(0xFF13192B),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
            onPressed: () => _showDeleteDialog(context, viewModel),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              activity.name,
              style: const TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            const Text(
              'Tap tombol di bawah untuk menghitung',
              style: TextStyle(fontSize: 14, color: Colors.white60),
            ),
            const SizedBox(height: 36),
            // Kotak Counter Besar seperti referensi gambar kanan
            GestureDetector(
              onTap: () {
                viewModel.incrementCounter(activityId);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Counter bertambah 1'),
                    duration: Duration(milliseconds: 500),
                  ),
                );
              },
              child: Container(
                width: double.infinity,
                height: 220,
                decoration: BoxDecoration(
                  color: const Color(0xFFE9EDF4),
                  borderRadius: BorderRadius.circular(32),
                ),
                alignment: Alignment.center,
                child: Text(
                  '${activity.count}',
                  style: const TextStyle(
                    fontSize: 88,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1E293B),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 36),
            // Tombol Kurang (-) dan Tambah (+)
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF232D4B),
                    foregroundColor: Colors.white,
                    shape: const CircleBorder(),
                    padding: const EdgeInsets.all(20),
                  ),
                  onPressed: () {
                    if (activity.count > 0) {
                      viewModel.decrementCounter(activityId);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Counter berkurang 1'),
                          duration: Duration(milliseconds: 500),
                        ),
                      );
                    }
                  },
                  child: const Icon(Icons.remove, size: 32),
                ),
                const SizedBox(width: 36),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF5A9E6F),
                    foregroundColor: Colors.white,
                    shape: const CircleBorder(),
                    padding: const EdgeInsets.all(20),
                  ),
                  onPressed: () {
                    viewModel.incrementCounter(activityId);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Counter bertambah 1'),
                        duration: Duration(milliseconds: 500),
                      ),
                    );
                  },
                  child: const Icon(Icons.add, size: 32),
                ),
              ],
            ),
            const SizedBox(height: 32),
            TextButton.icon(
              onPressed: () => _showResetDialog(context, viewModel),
              icon: const Icon(Icons.refresh, color: Colors.white70),
              label: const Text(
                'Reset Counter',
                style: TextStyle(color: Colors.white70, fontSize: 15),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
